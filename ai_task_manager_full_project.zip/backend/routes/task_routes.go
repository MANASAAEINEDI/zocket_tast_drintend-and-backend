package routes

import (
    "ai_task_manager/controllers"
    "github.com/gin-gonic/gin"
)

func TaskRoutes(r *gin.Engine) {
    tasks := r.Group("/tasks")
    {
        tasks.GET("/", controllers.GetTasks)
        tasks.POST("/", controllers.CreateTask)
    }
}

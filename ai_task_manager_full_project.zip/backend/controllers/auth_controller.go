package controllers

import (
    "ai_task_manager/config"
    "ai_task_manager/models"
    "ai_task_manager/utils"
    "github.com/gin-gonic/gin"
    "net/http"
)

func Register(c *gin.Context) {
    var user models.User
    if err := c.ShouldBindJSON(&user); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    user.Password = utils.HashPassword(user.Password)
    config.DB.Create(&user)
    c.JSON(http.StatusOK, gin.H{"message": "User registered successfully"})
}

func Login(c *gin.Context) {
    var user models.User
    var input models.User

    if err := c.ShouldBindJSON(&input); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    config.DB.Where("email = ?", input.Email).First(&user)

    if user.ID == 0 || !utils.CheckPasswordHash(input.Password, user.Password) {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
        return
    }

    token, _ := utils.GenerateJWT(user.ID)
    c.JSON(http.StatusOK, gin.H{"token": token})
}

package main

import (
    "ai_task_manager/config"
    "ai_task_manager/routes"
    "github.com/gin-gonic/gin"
)

func main() {
    r := gin.Default()
    config.ConnectDB()

    routes.AuthRoutes(r)
    routes.TaskRoutes(r)

    r.Run(":8080")
}

import { useState, useEffect } from "react";

export default function Home() {
    const [tasks, setTasks] = useState([]);

    useEffect(() => {
        fetch("http://localhost:8080/tasks")
            .then(res => res.json())
            .then(data => setTasks(data));
    }, []);

    return (
        <div className="container mx-auto">
            <h1 className="text-xl font-bold">Task List</h1>
            <ul>
                {tasks.map((task, index) => (
                    <li key={index} className="border p-2">{task.title}</li>
                ))}
            </ul>
        </div>
    );
}
